package com.example.covidwarning.Callbacks;

public interface LoginCallback {

    public void onCallback(Boolean isSuccessful,Exception e,String email);
}
