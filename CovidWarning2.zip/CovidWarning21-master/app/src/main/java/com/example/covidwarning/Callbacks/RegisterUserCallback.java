package com.example.covidwarning.Callbacks;

public interface RegisterUserCallback {

    public void  onCallback();

}
